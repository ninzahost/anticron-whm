<?php

if (getenv('REMOTE_USER') != 'root') 
	die('Access Denied.');

//$myversion = trim(file_get_contents('version.txt'));
$cptoken = getenv('cp_security_token');
$plugact=$_REQUEST['plugact'];


 require_once('/usr/local/cpanel/php/WHM.php');
 $headerString = WHM::getHeaderString("",1,0);
 echo($headerString);
 
 
 
$breadcrumbs_list='';
$head_title='Cron Management System';

$breadcrumbs_list .='<li><a href="'.$cptoken.'/scripts/command?PFILE=main"><span class="imageNode">Home</span></a><span> &raquo; </span></li>';

$breadcrumbs_list .='<li><a uniquekey="plugins" href="'.$cptoken.'/scripts/command?PFILE=Plugins"><span>Plugins</span></a><span> &raquo; </span></li>';

$breadcrumbs_list .='<li><a uniquekey="anticron" href="'.$cptoken.'/cgi/AntiCron/index.php"><span>Anticron</span></a></li>';

if($plugact=="listcron"){
$breadcrumbs_list .='<li><span> &raquo; </span><a uniquekey="'.$plugact.'" href="'.$cptoken.'/cgi/AntiCron/index.php?plugact='.$plugact.'"><span>Crons List</span></a></li>';
$head_title='Crons List';

}elseif($plugact=="managecrons"){
$breadcrumbs_list .='<li><span> &raquo; </span><a uniquekey="'.$plugact.'" href="'.$cptoken.'/cgi/AntiCron/index.php?plugact='.$plugact.'"><span>Manage Crons</span></a></li>';
$head_title='Manage Crons';

}elseif($plugact=="excludeuser"){
$breadcrumbs_list .='<li><span> &raquo; </span><a uniquekey="'.$plugact.'" href="'.$cptoken.'/cgi/AntiCron/index.php?plugact='.$plugact.'"><span>Exclude User</span></a></li>';	
$head_title='Exclude User';

}
 
?>

<script src="jquery/jquery.min.js" type="text/javascript"></script>
<link href="css/style.css" media="all" type="text/css" rel="stylesheet" />

<script type="text/javascript">
$("#breadcrumbs_list").html('<?php echo $breadcrumbs_list;?>');
</script>

<div class="panel panel-default" style="margin:25px 0;">
<h4><img src="img/anticron.png" style="padding-left: 15px"> Anticron - <?php echo $head_title;?></h4>
</div>

<div style="border-top:1px solid grey;text-align:left!important; font-size:11px;"></div>
	
	<?php

	if(!$plugact){ ?>
	
			<br>
			
			<div id="iconSea" class="panel-body">
				<div class="item" role="page" style="margin-right:18px;">
					<a uniquekey="general" href="<?php echo $cptoken; ?>/cgi/AntiCron/index.php?plugact=listcron" class="item-link">
						<img src="img/list.png" width="48">
						<span>Crons List</span>
					</a>
				</div>
				<div class="item" role="page" style="margin-right:15px;">
					<a uniquekey="general" href="<?php echo $cptoken; ?>/cgi/AntiCron/index.php?plugact=managecrons" class="item-link">
						<img src="icons/anticron.png" width="48">
						<span>Manage Crons</span>
					</a>
				</div>

				<div class="item" role="page" style="margin-right:15px;">
					<a uniquekey="general" href="<?php echo $cptoken; ?>/cgi/AntiCron/index.php?plugact=excludeuser" class="item-link">
						<img src="img/user.png" width="48">
						<span>Exclude User</span>
					</a>
				</div>



				<div class="item" role="page">
					<a uniquekey="info" href="#" class="item-link">
						<img src="icons/information.png">
						<span>Help</span>
					</a>
				</div>
			</div>
	<?php } 


if($plugact=="listcron"){
	
	
echo "<br><br><pre>";	
$c_dir="/var/spool/cron/";
$arr=array('.', '..','root'); 
$dir = opendir($c_dir);
$file = readdir($dir);
$i = 0;
while (false !== ($file = readdir($dir))) {
if(!in_array($file,$arr))
{
$usr=@file_get_contents($c_dir .$file);
$x=explode("\n",$usr);

if((count($x)-1) > 1 && strlen($usr) > 20)
{
echo $file ." => \n";
foreach($x as $nx)
{
if(stristr($nx, 'MAILTO=') == false &&  stristr($nx, 'SHELL="') == false && strlen($nx) > 10)
{
$xx=explode(" ",$nx,6);
echo $xx[0].' '.$xx[1].' '.$xx[2].' '.$xx[3].' '.$xx[4].' '.$xx[5]."\r\n";
}
}
echo "-------------------------------------------------------\n\n";
}
}
}     


echo "</pre><br><br>";	
	

	
}

	
if($plugact=="managecrons"){

$cron_file=__DIR__.'/cronslist';

if($_POST){
	
$anticron_status=$_POST['anticron_status'];	
	
$cronslist[]="* * * * *";	
for($i=1;$i<($_POST['crons']+1);$i++){
$cronslist[]="*/$i * * * *";	
}
$disable_crons=implode("\n",$cronslist);
@file_put_contents(__DIR__.'/cronslist',$disable_crons);

@file_put_contents(__DIR__.'/anticron_status',$anticron_status);

echo '<div class="success">Cron List Updated successfully</div>';

}


$anticron_status=@file_get_contents(__DIR__.'/anticron_status');
$anticron_status=($anticron_status=="on"?"checked":"");
$cron_file=@file_get_contents($cron_file);	
$cron_list=str_replace("\r\n","\n",$cron_file);
$cron_list_arr=explode("\n",$cron_list);
$cron_cnt=(count($cron_list_arr)-1);

	echo '<form method="POST" action="" style="margin: 10px 0 10px 10px;">
		
	<br>
	<select name="crons" class="form-control" style="max-width:50%;">';

$list=array('1','5','10','15','30');	
	
	foreach($list as $lst){

echo  '<option value="'.$lst.'" '.($cron_cnt==$lst?"selected":"").'>'.$lst.' Minute Crons</option>';		
	}
	
	echo '</select>
	<br>
	<label>
	<input type="checkbox" name="anticron_status" '.$anticron_status.' style="margin:10px 0;" name="anticron_status"> Tick this box to enable Anticron.
    </label>	
	<br>
	<br>
	<input type="submit" value="Submit" class="btn btn-primary">
	</form>';
	}
	
	
	
	
if($plugact=="excludeuser"){

$excluded_user="/usr/local/cpanel/whostmgr/docroot/cgi/AntiCron/excluded_user";

$users=$_POST['users'];
if($users==""){
$users="root\n";
}	

if($_POST['btn-submit']){
if(substr($users,0,4)=="root"){
@file_put_contents($excluded_user,$users);	
echo '<div class="success">User List Updated successfully</div>';
}else{
echo '<div class="warning ">User List Not Updated, Please Add `root` in fisrt line</div>';	
}

}

echo '<form method="POST" action="" style="margin: 20px 0 10px 15px; font-size:30px;max-width:70%;">
<textarea class="form-control" style="width:230px;" rows="8" name="users">'.@file_get_contents($excluded_user).'</textarea>
<input type="submit" name="btn-submit" value="Submit" class="btn btn-primary">
</form>';

}	
	
?>
<div class="footer" style="border-top:1px solid grey;text-align:center!important; font-size:11px;">
<b><a href="https://www.ninzahost.in" target="_blank">Anticron</a> </b>Copyright &copy; 2020 - <?php echo date("Y");?>
<a href="" target="_blank"></a>. All rights reserved.
</div>
</div>



