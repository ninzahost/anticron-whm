<?php
@ob_start();
@error_reporting(0);

$dis_cron_file="/usr/local/cpanel/whostmgr/docroot/cgi/AntiCron/cronslist";

if ((PHP_SAPI == 'cli'))
{
foreach ($argv as $arg)
{
list($arg_x, $arg_y) = explode('=', $arg);
$_GET[$arg_x] = $arg_y;
}
}

function replc(){
return $replc=rand(10,30).' '.rand(1,12).' * * *';	
}	

$check = array_key_exists("check", $_GET);
$do = array_key_exists("do", $_GET);
$chk=explode("\n",@file_get_contents($dis_cron_file));

$c_dir="/var/spool/cron/";

$excluded_user=@file_get_contents("/usr/local/cpanel/whostmgr/docroot/cgi/AntiCron/excluded_user");
$excluded_user=str_replace("\r\n","\n",$excluded_user);
$excluded_user=explode("\n",$excluded_user);
$arr=array('.', '..','root'); 
$excluded_user=array_merge($arr,$excluded_user);


if($check === true)
{
$dir = opendir($c_dir);
$file = readdir($dir);
$i = 0;
while (false !== ($file = readdir($dir))) { 
if(!in_array($file,$arr))
{
$usr=@file_get_contents($c_dir .$file);
$x=explode("\n",$usr);

if((count($x)-1) > 1 && strlen($usr) > 20)
{
echo $file ." => \n";
foreach($x as $nx)
{
if(stristr($nx, 'MAILTO=') == false &&  stristr($nx, 'SHELL="') == false && strlen($nx) > 10)
{
$xx=explode(" ",$nx,6);
echo $xx[0].' '.$xx[1].' '.$xx[2].' '.$xx[3].' '.$xx[4]."\r\n";
}
}
echo "-------------------------------------------------------\n";
}
}
}     
}


if($do === true)
{
	
	
$status=@file_get_contents("/usr/local/cpanel/whostmgr/docroot/cgi/AntiCron/anticron_status");	

if($status!="on"){
exit;
}	
	
$dir = opendir($c_dir);
$file = readdir($dir);
$i = 0;
while (false !== ($file = readdir($dir))) { 
if(!in_array($file,$excluded_user))
{

foreach($chk as $check){
$usr=@file_get_contents($c_dir .$file);

if(stristr($usr,$check) == true){
$n_cron=str_replace($check,replc(),$usr);
@file_put_contents($c_dir.$file,$n_cron);	
}
unset($usr);
}
}
}     
}


